#' Random
#'
#' Random Data.
#'
#' @format No Idea

#' @docType data
#' @keywords datasets
#' @name .Random.seed
#' @source Sean Sears
#'
".Random.seed"
